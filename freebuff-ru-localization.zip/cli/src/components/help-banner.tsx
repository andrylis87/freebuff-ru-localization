import React from 'react'
import { TextAttributes } from '@opentui/core'

import { useT } from '../i18n'
import { useTheme } from '../hooks/use-theme'
import { useTerminalDimensions } from '../hooks/use-terminal-dimensions'
import { IS_FREEBUFF } from '../utils/constants'

/**
 * Shortcut groups. English text lives here as the fallback for `t()` and is
 * what renders when the locale is `en`; the Russian catalog overrides each
 * `key`. Row keys are unique even where two rows share English copy (the two
 * "New line" rows), so a translation never gets reused by the wrong shortcut.
 */
const SECTIONS = [
  {
    key: 'compose',
    title: 'Compose',
    rows: [
      { shortcut: '/', key: 'commands', text: 'Commands' },
      { shortcut: '@files', key: 'mention-files', text: 'Mention files' },
      { shortcut: '@agents', key: 'use-agent', text: 'Use an agent' },
      { shortcut: 'Ctrl+J', key: 'newline-ctrl-j', text: 'New line' },
      { shortcut: 'Opt+Enter', key: 'newline-opt-enter', text: 'New line' },
      { shortcut: '/bash', key: 'shell-command', text: 'Shell command' },
    ],
  },
  {
    key: 'chat',
    title: 'Chat',
    rows: [
      { shortcut: '?', key: 'help', text: 'Help (empty input)' },
      { shortcut: '←', key: 'history', text: 'History (empty input)' },
      { shortcut: '↑ / ↓', key: 'prompts', text: 'Prompts (empty input)' },
      { shortcut: '/new', key: 'new-chat', text: 'New chat' },
      { shortcut: '/model', key: 'model-reasoning', text: 'Model / reasoning' },
      {
        shortcut: 'Ctrl+Q',
        key: 'edit-queued',
        text: 'Edit queued messages',
      },
    ],
  },
  {
    key: 'conversation',
    title: 'Conversation',
    rows: [
      { shortcut: 'Esc', key: 'close-help', text: 'Close help / stop' },
      {
        shortcut: 'Ctrl+C',
        key: 'clear-stop-quit',
        text: 'Clear / stop / quit',
      },
      {
        shortcut: 'Ctrl+T',
        key: 'toggle-agents',
        text: 'Expand / collapse agents',
      },
      { shortcut: '/copy', key: 'copy-chat', text: 'Copy chat' },
      { shortcut: '/export', key: 'export-chat', text: 'Export chat' },
      { shortcut: 'Drag', key: 'select-copy', text: 'Select and copy text' },
    ],
  },
] as const

/** Aligned shortcut columns; wrap whole columns on smaller terminals. */
export const HelpBanner = () => {
  const t = useT()
  const theme = useTheme()
  const { terminalWidth, terminalHeight } = useTerminalDimensions()
  const width = Math.max(16, terminalWidth - 4)
  const columnWidth = Math.min(37, width)
  const columns = Math.max(1, Math.floor((width + 2) / (columnWidth + 2)))
  const contentRows = Math.ceil(SECTIONS.length / columns) * 8 - 1 + (IS_FREEBUFF ? 0 : 2)
  return (
    <box
      style={{
        flexDirection: 'column',
        paddingLeft: 1,
        paddingRight: 1,
        marginBottom: 1,
        flexShrink: 0,
      }}
    >
      <text
        style={{
          fg: theme.foreground,
          attributes: TextAttributes.BOLD,
          marginBottom: 1,
        }}
      >
        {t('help.title', 'Keyboard shortcuts')}
      </text>
      <scrollbox
        style={{
          height: Math.min(contentRows, Math.max(5, Math.floor(terminalHeight / 2))),
          width: '100%',
        }}
        scrollX={false}
      >
        <box
          style={{
            flexDirection: 'row',
            flexWrap: 'wrap',
            columnGap: 2,
            rowGap: 1,
          }}
        >
          {SECTIONS.map((section) => (
            <box
              key={section.key}
              style={{
                flexDirection: 'column',
                width: columnWidth,
                flexShrink: 0,
              }}
            >
              <text
                style={{
                  fg: theme.foreground,
                  attributes: TextAttributes.BOLD,
                }}
              >
                {t(`help.section.${section.key}`, section.title)}
              </text>
              {section.rows
                .filter((row) => IS_FREEBUFF || row.shortcut !== '/model')
                .map((row) => (
                  <box key={row.key} style={{ flexDirection: 'row' }}>
                    <text
                      style={{ fg: theme.primary, width: 11, flexShrink: 0 }}
                    >
                      {row.shortcut}
                    </text>
                    <text
                      style={{
                        fg: theme.muted,
                        flexShrink: 1,
                        flexGrow: 1,
                        flexBasis: 0,
                        wrapMode: 'word',
                      }}
                    >
                      {t(`help.${section.key}.${row.key}`, row.text)}
                    </text>
                  </box>
                ))}
            </box>
          ))}
        </box>
        {!IS_FREEBUFF && (
          <text style={{ fg: theme.muted, marginTop: 1 }}>
            {t(
              'help.footer.credits',
              '/subscribe · /usage · 1 credit = 1 cent',
            )}
          </text>
        )}
      </scrollbox>
    </box>
  )
}
