import { FREEBUFF_DEFAULT_CONTEXT_WINDOW } from '@codebuff/common/constants/freebuff-models'
import { freebuffSessionUntimed } from '@codebuff/common/util/freebuff-model-selection'
import { TextAttributes } from '@opentui/core'
import React, { useEffect, useState } from 'react'

import { Button } from './button'
import { ScrollToBottomButton } from './scroll-to-bottom-button'
import { ShimmerText } from './shimmer-text'

import { useFreebuffSessionProgress } from '../hooks/use-freebuff-session-progress'
import { useTheme } from '../hooks/use-theme'
import { useT } from '../i18n'
import { useChatStore } from '../state/chat-store'
import { useFreebuffModelDirectory } from '../state/freebuff-catalog-store'
import { useByokSelectionStore } from '../utils/byok'
import { IS_FREEBUFF } from '../utils/constants'
import { freebucksOf } from '../utils/freebucks'
import { formatElapsedTime } from '../utils/format-elapsed-time'
import { formatContextUsage } from '../utils/format-token-count'
import {
  FREEBUFF_COUNTDOWN_VISIBLE_MS,
  formatFreebuffSessionCountdown,
  formatFreebuffSessionRemaining,
} from '../utils/freebuff-session-display'

import type { FreebuffSessionResponse } from '../types/freebuff-session'
import type { StatusIndicatorState } from '../utils/status-indicator-state'

/** A small status-bar action button with hover-bold styling. */
const StatusActionButton = ({
  children,
  onClick,
}: {
  children: React.ReactNode
  onClick: () => void
}) => {
  const theme = useTheme()
  const [hovered, setHovered] = useState(false)

  return (
    <Button
      style={{ paddingLeft: 1, paddingRight: 1 }}
      onClick={onClick}
      onMouseOver={() => setHovered(true)}
      onMouseOut={() => setHovered(false)}
    >
      <text>
        <span
          fg={theme.secondary}
          attributes={hovered ? TextAttributes.BOLD : TextAttributes.NONE}
        >
          {children}
        </span>
      </text>
    </Button>
  )
}

const SHIMMER_INTERVAL_MS = 160

interface StatusBarProps {
  timerStartTime: number | null
  isAtBottom: boolean
  scrollToLatest: () => void
  statusIndicatorState: StatusIndicatorState
  onStop?: () => void
  onEndSession?: () => void
  freebuffSession: FreebuffSessionResponse | null
}

export const StatusBar = ({
  timerStartTime,
  isAtBottom,
  scrollToLatest,
  statusIndicatorState,
  onStop,
  onEndSession,
  freebuffSession,
}: StatusBarProps) => {
  const theme = useTheme()
  const t = useT()
  const byok = useByokSelectionStore((state) => state.selected)
  const [elapsedSeconds, setElapsedSeconds] = useState(0)

  // Show timer when actively working (streaming or waiting for response) or paused (ask_user)
  // This uses statusIndicatorState as the single source of truth for "is the LLM working?"
  const shouldShowTimer =
    statusIndicatorState?.kind === 'waiting' ||
    statusIndicatorState?.kind === 'streaming' ||
    statusIndicatorState?.kind === 'paused'

  useEffect(() => {
    if (!timerStartTime || !shouldShowTimer) {
      setElapsedSeconds(0)
      return
    }

    // When paused, don't update the timer - just keep the frozen value
    if (statusIndicatorState?.kind === 'paused') {
      // Calculate current elapsed time once and freeze it
      const now = Date.now()
      const elapsed = Math.floor((now - timerStartTime) / 1000)
      setElapsedSeconds(elapsed)
      return
    }

    const updateElapsed = () => {
      const now = Date.now()
      const elapsed = Math.floor((now - timerStartTime) / 1000)
      setElapsedSeconds(elapsed)
    }

    updateElapsed()
    const interval = setInterval(updateElapsed, 1000)

    return () => clearInterval(interval)
  }, [timerStartTime, shouldShowTimer, statusIndicatorState?.kind])

  const sessionProgress = useFreebuffSessionProgress(freebuffSession)
  // The clock this session draws: none on a row the server marks untimed for
  // this viewer, whose next hour starts on the next send without a question.
  const clock =
    freebuffSession?.status === 'active' &&
    freebuffSessionUntimed(freebuffSession.model, freebucksOf(freebuffSession))
      ? null
      : sessionProgress
  const modelDirectory = useFreebuffModelDirectory()
  // A metered session is NOT unlimited, and the absence of `rateLimit` is no
  // longer evidence that it is: a Freebucks row carries no pool row at all, so
  // the old test reported "unlimited" for the one kind of session that was
  // actually bought. It still means unlimited off the meter, where an unpriced
  // row genuinely has no ceiling.
  const isUnlimited =
    freebuffSession?.status === 'active' &&
    !freebuffSession.rateLimit &&
    freebucksOf(freebuffSession) === undefined

  // Context occupancy of the main agent only: subagent states never land in
  // mainAgentState, so their tokens are excluded by construction. The store's
  // runState is written at end of turn, which is exactly when the idle branch
  // below renders — no mid-turn staleness is visible.
  const contextTokenCount = useChatStore(
    // Fully optional-chained: runState can be restored from a JSON.parse of
    // run-state.json with no shape validation, and a throwing selector would
    // crash the whole TUI.
    (state) =>
      state.runState?.sessionState?.mainAgentState?.contextTokenCount,
  )
  const contextWindow =
    freebuffSession?.status === 'active'
      ? modelDirectory.contextWindow(freebuffSession.model)
      : FREEBUFF_DEFAULT_CONTEXT_WINDOW
  const contextUsage =
    contextTokenCount !== undefined
      ? formatContextUsage(contextTokenCount, contextWindow)
      : null

  const renderStatusIndicator = () => {
    switch (statusIndicatorState.kind) {
      case 'ctrlC':
        return (
          <span fg={theme.secondary}>
            {t('status.exit-warning', 'Press Ctrl-C again to exit')}
          </span>
        )

      case 'clipboard':
        // Use green color for feedback success messages. Compared against the
        // same localized string feedback-container.tsx posts, so the check
        // holds in every locale (not just English).
        const isFeedbackSuccess =
          statusIndicatorState.message === t('feedback.sent', 'Feedback sent!')
        return (
          <span fg={isFeedbackSuccess ? theme.success : theme.primary}>
            {statusIndicatorState.message}
          </span>
        )

      case 'reconnected':
        return (
          <span fg={theme.success}>
            {t('status.reconnected', 'Reconnected')}
          </span>
        )

      case 'retrying':
        return (
          <ShimmerText
            text={t('status.retrying', 'retrying...')}
            primaryColor={theme.warning}
          />
        )

      case 'capacityWait':
        return (
          <ShimmerText
            text={t(
              'status.capacity-wait',
              'high demand — in line, starting soon...',
            )}
            primaryColor={theme.warning}
          />
        )

      case 'connecting':
        // The connection monitor starts optimistic; this state means a check failed.
        return (
          <span fg={theme.warning}>
            {t(
              'status.cannot-reach-servers',
              "Can't reach {brand}'s servers. Retrying… Try another network.",
              {
                brand: IS_FREEBUFF ? 'Freebuff' : 'Codebuff',
              },
            )}
          </span>
        )

      case 'waiting':
        return (
          <ShimmerText
            text={t('status.thinking', 'thinking...')}
            interval={SHIMMER_INTERVAL_MS}
            primaryColor={theme.secondary}
          />
        )

      case 'streaming':
        return (
          <ShimmerText
            text={t('status.working', 'working...')}
            interval={SHIMMER_INTERVAL_MS}
            primaryColor={theme.secondary}
          />
        )

      case 'paused':
        return null

      case 'idle':
        if (byok?.provider && byok.model) {
          const provider =
            byok.provider === 'openrouter'
              ? 'OpenRouter'
              : 'OpenAI-compatible'
          return <span fg={theme.secondary}>{`BYOK · ${provider} · ${byok.model}`}</span>
        }
        if (sessionProgress !== null) {
          const isUrgent =
            clock !== null && clock.remainingMs < FREEBUFF_COUNTDOWN_VISIBLE_MS
          // One template string on purpose: conditional text-node children
          // inside a <span> trip OpenTUI's reconciler (see knowledge.md).
          const idleLabel = [
            isUnlimited
              ? t('status.unlimited', 'unlimited')
              : clock && formatFreebuffSessionRemaining(clock.remainingMs),
            contextUsage,
          ]
            .filter(Boolean)
            .join(' · ')
          if (!idleLabel) return null
          return (
            <span
              fg={
                isUnlimited
                  ? theme.secondary
                  : isUrgent
                    ? theme.warning
                    : theme.secondary
              }
            >
              {idleLabel}
            </span>
          )
        }
        return null
    }
  }

  const renderElapsedTime = () => {
    if (!shouldShowTimer || elapsedSeconds === 0) {
      return null
    }

    return <span fg={theme.secondary}>{formatElapsedTime(elapsedSeconds)}</span>
  }

  const statusIndicatorContent = renderStatusIndicator()
  const elapsedTimeContent = renderElapsedTime()

  // Show gray background when there's status indicator, timer, or when the
  // freebuff session fill is visible (otherwise the fill would float over
  // transparent space).
  const hasContent =
    statusIndicatorContent || elapsedTimeContent || sessionProgress !== null

  return (
    <box
      style={{
        // Same full-width parent as the composer's bordered box.
        width: '100%',
        flexShrink: 0,
        flexDirection: 'row',
        alignItems: 'center',
        paddingLeft: 1,
        paddingRight: 1,
        gap: 1,
        backgroundColor: hasContent ? theme.surface : 'transparent',
      }}
    >
      {clock !== null && (
        <box
          style={{
            position: 'absolute',
            zIndex: 0,
            left: 0,
            top: 0,
            bottom: 0,
            // Fill anchors left and shrinks as time passes — the draining
            // bar is the countdown; no separate numeric readout needed.
            width: `${clock.fraction * 100}%`,
            // A green tint keeps the countdown distinct from its gray track
            // while preserving contrast for the status text in either theme.
            backgroundColor: theme.name === 'light' ? '#c7e8b5' : '#28452a',
          }}
        />
      )}
      <box
        style={{
          // Keep text above the fill even when it mounts after these columns.
          zIndex: 1,
          flexGrow: 1,
          flexShrink: 1,
          flexBasis: 0,
        }}
      >
        <text
          style={{
            wrapMode: statusIndicatorState.kind === 'connecting' ? 'word' : 'none',
          }}
        >
          {statusIndicatorContent}
        </text>
      </box>

      <box style={{ flexShrink: 0, zIndex: 1 }}>
        {!isAtBottom && <ScrollToBottomButton onClick={scrollToLatest} />}
      </box>

      <box
        style={{
          zIndex: 1,
          flexGrow: statusIndicatorState.kind === 'connecting' ? 0 : 1,
          flexShrink: 1,
          flexBasis: statusIndicatorState.kind === 'connecting' ? 'auto' : 0,
          flexDirection: 'row',
          justifyContent: 'flex-end',
          alignItems: 'center',
          gap: 1,
        }}
      >
        <text style={{ wrapMode: 'none' }}>{elapsedTimeContent}</text>
        {onStop &&
          (statusIndicatorState.kind === 'waiting' ||
            statusIndicatorState.kind === 'streaming') && (
            <StatusActionButton onClick={onStop}>■ Esc</StatusActionButton>
          )}
        {onEndSession &&
          statusIndicatorState.kind === 'idle' &&
          freebuffSession?.status === 'active' && (
            <StatusActionButton onClick={onEndSession}>
              ✕ End session
            </StatusActionButton>
          )}
        {clock !== null &&
          clock.remainingMs < FREEBUFF_COUNTDOWN_VISIBLE_MS &&
          statusIndicatorState.kind !== 'idle' &&
          !isUnlimited && (
            <text style={{ wrapMode: 'none' }}>
              <span fg={theme.warning} attributes={TextAttributes.BOLD}>
                {formatFreebuffSessionCountdown(clock.remainingMs)}
              </span>
            </text>
          )}
      </box>
    </box>
  )
}
