import { t } from '../i18n'
import { AGENT_MODES, IS_FREEBUFF } from '../utils/constants'

import type { SkillsMap } from '@codebuff/common/types/skill'


export interface SlashCommand {
  id: string
  label: string
  description: string
  aliases?: string[]
  /**
   * If true, this command can be invoked without a leading slash when the
   * input matches the command id exactly (no arguments).
   */
  implicitCommand?: boolean
  /**
   * If set, selecting this command inserts this text into the input field
   * instead of executing a command. Useful for agent shortcuts.
   */
  insertText?: string
}

// Generate mode commands from the AGENT_MODES constant (excluded in Freebuff)
const MODE_COMMANDS: SlashCommand[] = IS_FREEBUFF
  ? []
  : AGENT_MODES.map((mode) => ({
      id: `mode:${mode.toLowerCase()}`,
      label: `mode:${mode.toLowerCase()}`,
      description: `Switch to ${mode} mode`,
      aliases: [`model:${mode.toLowerCase()}`],
    }))

const FREEBUFF_REMOVED_COMMAND_IDS = new Set([
  'ads:enable',
  'ads:disable',
  'usage',
  'subscribe',
  'agent:gpt-5',
  'image',
  'publish',
  'init',
])

const FREEBUFF_ONLY_COMMAND_IDS = new Set([
  'byok',
  'plan',
  'end-session',
  'model',
  'reasoning',
  'dashboard',
  'deals',
])

const ALL_SLASH_COMMANDS: SlashCommand[] = [
  {
    id: 'ads:report',
    label: 'ads:report',
    description: 'Explain a problem with an ad: /ads:report <number> (or list recent ads)',
  },
  {
    id: 'help',
    label: 'help',
    description: 'Display keyboard shortcuts and tips',
    aliases: ['h', '?'],
    implicitCommand: true,
  },
  {
    id: 'diagnostics',
    label: 'diagnostics',
    description: 'Show local CLI resource usage and terminal tool process IDs',
    aliases: ['diag', 'processes'],
  },
  {
    id: 'ads:enable',
    label: 'ads:enable',
    description: 'Enable contextual ads',
  },
  {
    id: 'ads:disable',
    label: 'ads:disable',
    description: 'Disable contextual ads',
  },
  {
    id: 'init',
    label: 'init',
    description: 'Create a starter knowledge.md file',
    implicitCommand: true,
  },
  // {
  //   id: 'undo',
  //   label: 'undo',
  //   description: 'Undo the last change made by the assistant',
  // },
  // {
  //   id: 'redo',
  //   label: 'redo',
  //   description: 'Redo the most recent undone change',
  // },
  {
    id: 'usage',
    label: 'usage',
    description: 'View credits and subscription quota',
    aliases: ['credits'],
  },
  {
    id: 'subscribe',
    label: 'subscribe',
    description: 'Subscribe to get more usage',
    aliases: ['strong', 'sub', 'buy-credits'],
  },
  {
    id: 'interview',
    label: 'interview',
    description: 'AI asks a series of questions to flesh out request into a spec',
  },
  {
    id: 'plan',
    label: 'plan',
    description: 'Create a plan for how to implement a request',
  },
  {
    id: 'review',
    label: 'review',
    description: 'Review code changes',
  },
  {
    id: 'queue',
    label: 'queue',
    description: 'Edit, reorder, or delete the messages waiting to be sent',
    aliases: ['queued'],
  },
  {
    id: 'todo',
    label: 'todo',
    description: 'View the current checklist and progress',
    aliases: ['todos'],
  },
  {
    id: 'new',
    label: 'new',
    description: 'Clear the conversation history and start a new chat',
    aliases: ['n', 'clear', 'c', 'reset'],
    implicitCommand: true,
  },
  {
    id: 'history',
    label: 'history',
    description: 'Browse and resume past conversations',
    aliases: ['chats'],
  },
  {
    id: 'copy',
    label: 'copy',
    description: 'Copy the full conversation (messages + tool results) to the clipboard',
    aliases: ['copy-chat'],
  },
  {
    id: 'export',
    label: 'export',
    description: 'Write the full conversation to a file (.md, or .json for raw messages)',
    aliases: ['export-chat'],
  },
  {
    id: 'agent:gpt-5',
    label: 'agent:gpt-5',
    description: 'Spawn the GPT-5 agent to help solve complex problems',
    insertText: '@GPT-5 Agent ',
  },
  // {
  //   id: 'agent:opus',
  //   label: 'agent:opus',
  //   description: 'Spawn the Opus agent to help solve any problem',
  //   insertText: '@Opus Agent ',
  // },
  {
    id: 'feedback',
    label: 'feedback',
    // `{brand}` is resolved when the menu is built (see
    // getSlashCommandsWithSkills), so English renders exactly as before while
    // the Russian catalog reuses the same placeholder.
    description: 'Share general feedback about {brand}',
  },
  {
    id: 'bash',
    label: 'bash',
    description: 'Enter bash mode ("!" at beginning enters bash mode)',
    aliases: ['!'],
  },
  {
    id: 'image',
    label: 'image',
    description: 'Attach an image file (or Ctrl+V to paste from clipboard)',
    aliases: ['img', 'attach'],
  },
  ...MODE_COMMANDS,
  // {
  //   id: 'publish',
  //   label: 'publish',
  //   description: 'Publish agents to the agent store',
  // },
  {
    id: 'theme:toggle',
    label: 'theme:toggle',
    description: 'Toggle between light and dark mode',
  },
  {
    id: 'language',
    label: 'language',
    description: 'Show or change the interface language',
    aliases: ['lang', 'locale'],
  },
  {
    id: 'byok',
    label: 'byok',
    description: 'Manage direct OpenRouter or OpenAI-compatible inference',
    aliases: ['provider'],
  },
  {
    id: 'model',
    label: 'model',
    description: 'Choose the model for your next message',
  },
  {
    id: 'reasoning',
    label: 'reasoning',
    description: 'Choose reasoning effort for your next message model',
    aliases: ['effort', 'think'],
  },
  {
    id: 'deals',
    label: 'deals',
    description: 'Sponsored offers: /deals use <n> opens one, /deals off hides them',
  },
  {
    id: 'end-session',
    label: 'end-session',
    description: 'End your current session',
  },
  {
    id: 'dashboard',
    label: 'dashboard',
    description: 'Open your usage, streak and account dashboard in the browser',
    aliases: ['usage', 'stats', 'streak'],
  },
  {
    id: 'logout',
    label: 'logout',
    description: 'Sign out of your session',
    aliases: ['signout'],
    implicitCommand: true,
  },
  {
    id: 'exit',
    label: 'exit',
    description: 'Quit the CLI',
    aliases: ['quit', 'q'],
    implicitCommand: true,
  },
]

export const SLASH_COMMANDS = IS_FREEBUFF
  ? ALL_SLASH_COMMANDS.filter(
      (cmd) => !FREEBUFF_REMOVED_COMMAND_IDS.has(cmd.id),
    )
  : ALL_SLASH_COMMANDS.filter((cmd) => !FREEBUFF_ONLY_COMMAND_IDS.has(cmd.id))

export const SLASHLESS_COMMAND_IDS = new Set(
  SLASH_COMMANDS.filter((cmd) => cmd.implicitCommand).map((cmd) =>
    cmd.id.toLowerCase(),
  ),
)

/** Maximum description length for skill commands in the slash menu */
const SKILL_MENU_DESCRIPTION_MAX_LENGTH = 50

function truncateDescription(description: string): string {
  if (description.length <= SKILL_MENU_DESCRIPTION_MAX_LENGTH) {
    return description
  }
  return description.slice(0, SKILL_MENU_DESCRIPTION_MAX_LENGTH - 1) + '…'
}

/**
 * Returns SLASH_COMMANDS merged with skill commands.
 * Skills become slash commands that users can invoke directly.
 *
 * Command descriptions are localized here rather than at module scope so a
 * `/language` switch takes effect on the next menu open: the English text
 * stays in the data file as the fallback, and `cmd.<id>.description` in the
 * catalog overrides it per locale. Skill descriptions are deliberately NOT
 * localized — they are content authored in the project's SKILL.md files, not
 * our UI copy.
 */
export function getSlashCommandsWithSkills(skills: SkillsMap): SlashCommand[] {
  const skillCommands: SlashCommand[] = Object.values(skills).map((skill) => ({
    id: `skill:${skill.name}`,
    label: `skill:${skill.name}`,
    description: truncateDescription(skill.description),
    insertText: `/skill:${skill.name} `,
  }))

  const localizedCommands = SLASH_COMMANDS.map((command) => ({
    ...command,
    description: t(`cmd.${command.id}.description`, command.description, {
      brand: IS_FREEBUFF ? 'Freebuff' : 'Codebuff',
    }),
  }))

  const commands = [...localizedCommands, ...skillCommands]

  return commands
}
