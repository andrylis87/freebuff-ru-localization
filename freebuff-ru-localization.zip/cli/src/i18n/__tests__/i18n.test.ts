import fs from 'fs'
import os from 'os'
import path from 'path'

import {
  afterEach,
  beforeAll,
  afterAll,
  describe,
  expect,
  spyOn,
  test,
} from 'bun:test'

import { detectLocaleFromEnvironment } from '../detect'
import {
  formatDate,
  formatNumber,
  getLocale,
  initLocale,
  isLocaleInitialized,
  parseLocale,
  resetLocaleForTests,
  setLocale,
  t,
  tp,
} from '../index'
import {
  DEFAULT_LOCALE,
  LOCALE_LABELS,
  SUPPORTED_LOCALES,
  type Locale,
} from '../types'

import * as auth from '../../utils/auth'

/**
 * The suite pins the locale itself: these tests are the contract for
 * `t()`/`tp()`, so they must not depend on the machine that runs them. That is
 * also why production code only ever initializes the locale explicitly
 * (`initLocale` at startup) — nothing here calls it implicitly.
 */

const ENV_KEYS = [
  'FREEBUFF_LOCALE',
  'CODEBUFF_LOCALE',
  'LC_ALL',
  'LC_MESSAGES',
  'LANG',
] as const

const originalEnv: Record<string, string | undefined> = {}

/** Set the locale-related env vars, remembering what was there before. */
const setEnv = (
  values: Partial<Record<(typeof ENV_KEYS)[number], string>>,
): void => {
  for (const key of ENV_KEYS) {
    if (!(key in originalEnv)) originalEnv[key] = process.env[key]
    const value = values[key]
    if (value === undefined) delete process.env[key]
    else process.env[key] = value
  }
}

const restoreEnv = (): void => {
  for (const key of ENV_KEYS) {
    const value = originalEnv[key]
    if (value === undefined) delete process.env[key]
    else process.env[key] = value
    delete originalEnv[key]
  }
}

let testConfigDir: string | undefined
let getConfigDirSpy: ReturnType<typeof spyOn> | undefined

/**
 * Every test in this file gets a throwaway config dir for the WHOLE file, not
 * per test: `setLocale()` and `loadSettings()` both touch the settings file, so
 * without this a unit test would read and rewrite the developer's real
 * `settings.json` (and leave a `language` pick behind it).
 */
beforeAll(() => {
  testConfigDir = fs.mkdtempSync(path.join(os.tmpdir(), 'freebuff-i18n-test-'))
  getConfigDirSpy = spyOn(auth, 'getConfigDir').mockReturnValue(testConfigDir)
})

afterAll(() => {
  getConfigDirSpy?.mockRestore()
  getConfigDirSpy = undefined
  if (testConfigDir) {
    fs.rmSync(testConfigDir, { recursive: true, force: true })
    testConfigDir = undefined
  }
})

/** Fails fast when the temp config dir from beforeAll is gone. */
const freshSettings = (): void => {
  if (!testConfigDir) {
    throw new Error('temp config dir missing — beforeAll did not run')
  }
}

const writeSettings = (settings: Record<string, unknown>): void => {
  freshSettings()
  fs.writeFileSync(
    path.join(testConfigDir!, 'settings.json'),
    JSON.stringify(settings, null, 2),
  )
}

const readSettings = (): Record<string, unknown> =>
  JSON.parse(
    fs.readFileSync(path.join(testConfigDir!, 'settings.json'), 'utf8'),
  )

afterEach(() => {
  resetLocaleForTests()
  // Start every test from "no settings file": a pick persisted by an earlier
  // test must not be visible to the next one.
  if (testConfigDir) {
    fs.rmSync(path.join(testConfigDir, 'settings.json'), { force: true })
  }
  restoreEnv()
})

describe('locale metadata', () => {
  test('ships exactly the locales the CLI advertises', () => {
    expect([...SUPPORTED_LOCALES]).toEqual(['en', 'ru'])
    expect(DEFAULT_LOCALE).toBe('en')
    expect(LOCALE_LABELS.en).toBe('English')
    expect(LOCALE_LABELS.ru).toBe('Русский')
  })
})

describe('t()', () => {
  test('renders the English fallback by default', () => {
    expect(getLocale()).toBe('en')
    expect(t('any.key', 'English text')).toBe('English text')
  })

  test('renders the Russian catalog under the ru locale', () => {
    setLocale('ru')
    expect(t('help.title', 'Keyboard shortcuts')).toBe('Горячие клавиши')
  })

  test('falls back to English for a key the catalog does not have', () => {
    setLocale('ru')
    expect(t('not.a.real.key', 'English text')).toBe('English text')
  })

  test('interpolates {name} and {{name}} with identical token names', () => {
    expect(t('a', 'Hello {name}!', { name: 'Ada' })).toBe('Hello Ada!')
    expect(t('b', 'Hello {{name}}!', { name: 'Ada' })).toBe('Hello Ada!')
    setLocale('ru')
    expect(
      t('lang.changed', 'Язык интерфейса переключён на {name} ({locale}).', {
        name: 'Русский',
        locale: 'ru',
      }),
    ).toBe('Язык интерфейса переключён на Русский (ru).')
  })

  test('leaves a placeholder with no value untouched', () => {
    expect(t('a', 'Missing {name} stays')).toBe('Missing {name} stays')
    expect(t('a', 'Missing {name} stays', { other: 'x' })).toBe(
      'Missing {name} stays',
    )
  })

  test('never rewrites ${...}, %s/%d or braces used as literal text', () => {
    expect(t('a', 'Runs ${x} and %s and %d', { x: '1' })).toBe(
      'Runs ${x} and %s and %d',
    )
    expect(t('b', 'JSON {"a": 1}', { a: 'nope' })).toBe('JSON {"a": 1}')
  })

  test('keeps line breaks and markup intact in both locales', () => {
    const source = 'First line\nSecond <b>line</b>'
    expect(t('a', source)).toBe(source)
    setLocale('ru')
    expect(t('a', source)).toBe(source)
  })
})

describe('tp()', () => {
  const forms = { one: '{count} file', other: '{count} files' }

  test('uses English one/other under the en locale', () => {
    expect(tp('files.count', 1, forms)).toBe('1 file')
    expect(tp('files.count', 2, forms)).toBe('2 files')
  })

  test('uses all four Russian plural categories', () => {
    setLocale('ru')
    expect(tp('ru.demo', 1, forms)).toBe('1 файл')
    expect(tp('ru.demo', 2, forms)).toBe('2 файла')
    expect(tp('ru.demo', 5, forms)).toBe('5 файлов')
    expect(tp('ru.demo', 0, forms)).toBe('0 файлов')
    expect(tp('ru.demo', 1.5, forms)).toBe('1,5 файла')
  })

  test('falls back to the English forms when the catalog has no entry', () => {
    setLocale('ru')
    expect(tp('nothing.here', 3, forms)).toBe('3 files')
  })

  test('always exposes {count} alongside caller params', () => {
    expect(
      tp('files.count', 7, { other: '{count} of {total}' }, { total: 9 }),
    ).toBe('7 of 9')
  })
})

const PARSE_CASES: [input: string, expected: Locale | undefined][] = [
  ['ru', 'ru'],
  ['RU', 'ru'],
  ['ru-RU', 'ru'],
  ['ru_RU.UTF-8', 'ru'],
  ['en', 'en'],
  ['EN-US', 'en'],
  ['fr', undefined],
  ['', undefined],
  ['русский', undefined],
]

describe('parseLocale()', () => {
  test.each(PARSE_CASES)('parses %s as %s', (value, expected) => {
    expect(parseLocale(value)).toBe(expected)
  })
})

describe('detectLocaleFromEnvironment()', () => {
  test('reads the explicit override first', () => {
    setEnv({ FREEBUFF_LOCALE: 'ru', LANG: 'en_US.UTF-8' })
    expect(detectLocaleFromEnvironment()).toBe('ru')
  })

  test('reads a POSIX LANG tag', () => {
    setEnv({ LANG: 'ru_RU.UTF-8' })
    expect(detectLocaleFromEnvironment()).toBe('ru')
  })

  test('lets LC_ALL override a ru-flavoured LANG', () => {
    setEnv({ LC_ALL: 'en_US.UTF-8', LANG: 'ru_RU.UTF-8' })
    expect(detectLocaleFromEnvironment()).toBe('en')
  })

  test('treats C/POSIX as "no answer" rather than a language', () => {
    setEnv({ LC_ALL: 'C', LANG: 'ru_RU.UTF-8' })
    expect(detectLocaleFromEnvironment()).toBe('ru')
  })

  test('falls back to the ICU system locale when no env var is set', () => {
    setEnv({})
    // With nothing exported there is no POSIX answer, so detection reads
    // Intl's resolved locale — and must still land on a supported language.
    const icu = Intl.DateTimeFormat().resolvedOptions().locale.toLowerCase()
    expect(detectLocaleFromEnvironment()).toBe(
      icu.startsWith('ru') ? 'ru' : 'en',
    )
  })
})

describe('initLocale()', () => {
  test('prefers the saved /language choice over the environment', () => {
    setEnv({ LANG: 'en_US.UTF-8' })
    writeSettings({ language: 'ru' })

    expect(initLocale()).toBe('ru')
  })

  test('auto-detects when nothing is saved, without writing a choice back', () => {
    setEnv({ LANG: 'ru_RU.UTF-8' })

    expect(initLocale()).toBe('ru')
    expect(readSettings().language).toBeUndefined()
  })

  test('a saved choice is never overwritten by a later init', () => {
    writeSettings({ language: 'en' })
    expect(initLocale()).toBe('en')

    setEnv({ LANG: 'ru_RU.UTF-8' })
    expect(initLocale()).toBe('en')
  })

  test('setLocale persists the choice so it survives restarts', () => {
    initLocale()
    setLocale('ru')

    expect(readSettings().language).toBe('ru')
    expect(getLocale()).toBe('ru')
  })

  test('drops a language this build cannot serve', () => {
    writeSettings({ language: 'fr' })

    expect(initLocale()).toBe('en')
  })

  test('reports initialization and is idempotent', () => {
    expect(isLocaleInitialized()).toBe(false)
    initLocale()
    expect(isLocaleInitialized()).toBe(true)
    expect(initLocale()).toBe(getLocale())
  })
})

describe('Intl formatters', () => {
  test('formatNumber follows the active locale', () => {
    expect(formatNumber(1234.5)).toBe('1,234.5')
    setLocale('ru')
    const ru = formatNumber(1234.5)
    expect(ru).toContain(',')
    expect(ru).not.toContain('.')
  })

  test('formatDate follows the active locale', () => {
    const moment = Date.UTC(2026, 9, 26, 12, 0, 0)
    expect(formatDate(moment, { timeZone: 'UTC', month: 'long' })).toBe(
      'October',
    )

    setLocale('ru')
    expect(
      formatDate(moment, { timeZone: 'UTC', month: 'long', day: 'numeric' }),
    ).toBe('26 октября')
  })
})
