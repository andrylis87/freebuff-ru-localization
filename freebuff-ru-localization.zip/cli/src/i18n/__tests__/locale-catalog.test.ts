import fs from 'fs'
import path from 'path'

import { describe, expect, test } from 'bun:test'

import { RU_MESSAGES } from '../locales/ru'

/**
 * Quality gate for the Russian catalog.
 *
 * English is NOT stored in the catalog — it lives at each call site as the
 * `fallback` argument (or as `tp()`'s inline English forms) and is what renders
 * under the default `en` locale. That makes the code the single source of
 * truth for English, so this suite reads the source back and checks the
 * catalog against it:
 *
 *  1. no duplicate keys (an object literal would silently keep the last one),
 *  2. well-formed, namespaced keys,
 *  3. every value actually contains Russian (a copy-pasted English string
 *     that slipped in as a "translation"),
 *  4. every key still has English in the code — a stale key for a string that
 *     no longer exists fails loudly,
 *  5. placeholder parity with that English ({name} / {{name}} / %s / ${...}),
 *  6. complete Russian plural families (one / few / many / other).
 *
 * "Missing key" is a different failure mode and is covered by i18n.test.ts: a
 * key absent from the catalog must render its English fallback, never an empty
 * string or the raw key.
 */

const I18N_DIR = path.resolve(import.meta.dir, '..')
const CLI_SRC = path.resolve(I18N_DIR, '..')

const RU_SOURCE = fs.readFileSync(
  path.join(I18N_DIR, 'locales', 'ru.ts'),
  'utf8',
)

/** Every non-test .ts/.tsx file under cli/src: test files are excluded so an
 *  assertion that happens to quote a string cannot masquerade as the English
 *  source of a catalog key. Keys used ONLY by tests are listed in
 *  TEST_FIXTURE_KEYS below. */
const listSourceFiles = (dir: string): string[] => {
  const out: string[] = []
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name)
    if (entry.isDirectory()) {
      if (entry.name === 'node_modules' || entry.name === 'dist') continue
      out.push(...listSourceFiles(full))
    } else if (
      /\.tsx?$/.test(entry.name) &&
      !/\.test\.tsx?$/.test(entry.name)
    ) {
      out.push(full)
    }
  }
  return out
}

/** Catalog keys with no production call site because they exist only to
 *  exercise the runtime (i18n.test.ts). Checked for shape, skipped for
 *  coverage and placeholder parity. */
const TEST_FIXTURE_KEYS = new Set(['ru.demo'])
const isFixture = (key: string): boolean =>
  TEST_FIXTURE_KEYS.has(key) ||
  [...TEST_FIXTURE_KEYS].some((base) => key.startsWith(`${base}.`))

const SOURCE_FILES = listSourceFiles(CLI_SRC)
const SOURCE_OF = new Map<string, string>(
  SOURCE_FILES.map((file) => [file, fs.readFileSync(file, 'utf8')]),
)
const ALL_SOURCE = [...SOURCE_OF.values()].join('\n')

const readRelative = (relative: string): string =>
  fs.readFileSync(path.join(CLI_SRC, relative), 'utf8')

/** Placeholder names in a template, both `{x}` and `{{x}}`. */
const placeholders = (template: string): Set<string> => {
  const found = new Set<string>()
  for (const match of template.matchAll(
    /\{\{([A-Za-z0-9_]+)\}\}|\{([A-Za-z0-9_]+)\}/g,
  )) {
    found.add((match[1] ?? match[2]) as string)
  }
  return found
}

const samePlaceholders = (a: Set<string>, b: Set<string>): boolean =>
  a.size === b.size && [...a].every((token) => b.has(token))

// --- English source lookup -------------------------------------------------

/** `t('key', 'English…')` calls, tolerating either quote style and newlines
 *  between the arguments. */
const literalCalls = (): Map<string, string> => {
  const found = new Map<string, string>()
  const pattern =
    /\bt\(\s*(['"])((?:\\.|(?!\1)[^\\])*)\1\s*,\s*(['"])((?:\\.|(?!\3)[^\\])*)\3/g
  for (const [, , key, , fallback] of ALL_SOURCE.matchAll(pattern)) {
    if (!found.has(key)) found.set(key, fallback)
  }
  return found
}

/** Extract the full text of `tp(\n  '<base>' …)` so its English forms can be
 *  read. Whitespace between `tp(` and the key is tolerated because the call
 *  site may be wrapped over several lines. */
const findTpCall = (base: string): string | null => {
  const escaped = base.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  const open = new RegExp(String.raw`tp\(\s*'${escaped}'`)
  const from = ALL_SOURCE.search(open)
  if (from === -1) return null

  let depth = 0
  let quote: string | null = null
  for (let i = from + 2; i < ALL_SOURCE.length; i++) {
    const char = ALL_SOURCE[i] as string
    if (quote) {
      if (char === '\\') {
        i++
        continue
      }
      if (char === quote) quote = null
      continue
    }
    if (char === "'" || char === '"') {
      quote = char
      continue
    }
    if (char === '(') depth++
    else if (char === ')') {
      depth--
      if (depth === 0) return ALL_SOURCE.slice(from, i + 1)
    }
  }
  return null
}

/** `cmd.<id>.description` → the `description:` literal for that id. */
const slashCommandDescriptions = (): Map<string, string> => {
  const source = readRelative('data/slash-commands.ts')
  const found = new Map<string, string>()
  const pattern =
    /\bid:\s*'([^']+)'[\s\S]*?\bdescription:\s*(?:'((?:\\.|[^'\\])*)'|"((?:\\.|[^"\\])*)")/g
  for (const match of source.matchAll(pattern)) {
    found.set(`cmd.${match[1]}.description`, (match[2] ?? match[3]) as string)
  }
  return found
}

/** `input.mode.<mode>.<field>` → the English `label`/`placeholder`. */
const inputModeStrings = (): Map<string, string> => {
  const source = readRelative('utils/input-modes.ts')
  const found = new Map<string, string>()
  for (const match of source.matchAll(/^  (\w+): \{([\s\S]*?)^  \},?$/gm)) {
    const mode = (match[1] as string).toLowerCase()
    const body = match[2] as string
    const label = body.match(/\blabel:\s*'((?:\\.|[^'\\])*)'/)
    const placeholder = body.match(/\bplaceholder:\s*'((?:\\.|[^'\\])*)'/)
    if (label) found.set(`input.mode.${mode}.label`, label[1] as string)
    if (placeholder) {
      found.set(`input.mode.${mode}.placeholder`, placeholder[1] as string)
    }
  }
  return found
}

/** `help.section.<k>` and `help.<section>.<row>` → English copy in SECTIONS. */
const helpBannerStrings = (): Map<string, string> => {
  const source = readRelative('components/help-banner.tsx')
  const marks: { index: number; key: string; text: string }[] = []

  for (const match of source.matchAll(
    /\bkey:\s*'([a-z-]+)',\s*\n\s*title:\s*'([^']*)'/g,
  )) {
    marks.push({
      index: match.index ?? 0,
      key: `help.section.${match[1]}`,
      text: match[2] as string,
    })
  }
  // No trailing comma in the pattern: a one-line row closes with ` },` so the
  // comma sits after the brace, while a wrapped row does have one after the
  // text. Requiring it hid every one-line row from this scan.
  for (const match of source.matchAll(
    /\bkey:\s*'([a-z-]+)',\s*\n?\s*text:\s*'([^']*)'/g,
  )) {
    marks.push({
      index: match.index ?? 0,
      key: `__row__${match[1]}`,
      text: match[2] as string,
    })
  }

  marks.sort((a, b) => a.index - b.index)
  const found = new Map<string, string>()
  let section: string | null = null
  for (const mark of marks) {
    if (mark.key.startsWith('help.section.')) {
      section = mark.key.slice('help.section.'.length)
      found.set(mark.key, mark.text)
    } else if (section) {
      found.set(
        `help.${section}.${mark.key.slice('__row__'.length)}`,
        mark.text,
      )
    }
  }
  return found
}

const LITERAL_CALLS = literalCalls()
const SLASH_DESCRIPTIONS = slashCommandDescriptions()
const INPUT_MODE_STRINGS = inputModeStrings()
const HELP_STRINGS = helpBannerStrings()

const PLURAL_SUFFIX = /\.(one|few|many|other)$/

/** English text backing a catalog key, or null when it cannot be found —
 *  which for a catalog key means the key is stale. */
const englishFor = (key: string): string | null => {
  const literal = LITERAL_CALLS.get(key)
  if (literal !== undefined) return literal

  const plural = key.match(PLURAL_SUFFIX)
  if (plural) {
    const call = findTpCall(key.slice(0, plural.index ?? key.length))
    return call
  }

  return (
    SLASH_DESCRIPTIONS.get(key) ??
    INPUT_MODE_STRINGS.get(key) ??
    HELP_STRINGS.get(key) ??
    null
  )
}

// --- the suite -------------------------------------------------------------

describe('ru catalog: shape', () => {
  const declared = [...RU_SOURCE.matchAll(/^\s*'([^']+)':/gm)].map(
    (match) => match[1] as string,
  )

  test('declares no key twice (the object literal would hide it)', () => {
    const duplicates = declared.filter(
      (key, index) => declared.indexOf(key) !== index,
    )
    expect([...new Set(duplicates)]).toEqual([])
  })

  test('source and runtime agree on how many keys there are', () => {
    expect(declared.length).toBe(Object.keys(RU_MESSAGES).length)
  })

  test('every key is namespaced and lower-case', () => {
    const malformed = Object.keys(RU_MESSAGES).filter(
      (key) => !/^[a-z][a-z0-9]*(\.[a-z0-9:_-]+)+$/.test(key),
    )
    expect(malformed).toEqual([])
  })

  test('every value is actually Russian', () => {
    const untranslated = Object.entries(RU_MESSAGES)
      .filter(([, value]) => !/[а-яё]/i.test(value))
      .map(([key]) => key)
    expect(untranslated).toEqual([])
  })
})

describe('ru catalog: coverage against the code', () => {
  const keys = Object.keys(RU_MESSAGES)

  test('every key still has English in the code (no stale keys)', () => {
    const stale = keys
      .filter((key) => !isFixture(key))
      .filter((key) => englishFor(key) === null)
    expect(stale).toEqual([])
  })

  test('every key maps to a usable English string', () => {
    const empty = keys
      .filter((key) => !isFixture(key))
      .filter((key) => (englishFor(key) ?? '').length === 0)
    expect(empty).toEqual([])
  })
})

describe('ru catalog: placeholders', () => {
  const keys = Object.keys(RU_MESSAGES)

  test('placeholders match the English source one-for-one', () => {
    const mismatches: { key: string; english: string[]; russian: string[] }[] =
      []

    for (const key of keys) {
      if (isFixture(key)) continue
      const english = englishFor(key)
      if (english === null) continue // reported by the coverage suite
      const russian = RU_MESSAGES[key] as string
      if (!samePlaceholders(placeholders(english), placeholders(russian))) {
        mismatches.push({
          key,
          english: [...placeholders(english)],
          russian: [...placeholders(russian)],
        })
      }
    }

    expect(mismatches).toEqual([])
  })
})

describe('ru catalog: pluralization', () => {
  const pluralBases = [
    ...new Set(
      Object.keys(RU_MESSAGES)
        .filter((key) => PLURAL_SUFFIX.test(key))
        .map((key) => key.replace(PLURAL_SUFFIX, '')),
    ),
  ]

  test('has at least one pluralized string to prove the mechanism', () => {
    expect(pluralBases.length).toBeGreaterThan(0)
  })

  test('every pluralized key ships all four Russian forms', () => {
    const incomplete = pluralBases.filter((base) =>
      ['one', 'few', 'many', 'other'].some(
        (form) => !(`${base}.${form}` in RU_MESSAGES),
      ),
    )
    expect(incomplete).toEqual([])
  })

  test('every base key with Russian plural forms is called through tp()', () => {
    const unused = pluralBases
      .filter((base) => !isFixture(base))
      .filter((base) => findTpCall(base) === null)
    expect(unused).toEqual([])
  })
})
