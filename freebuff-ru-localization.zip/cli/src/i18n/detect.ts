/**
 * Locale auto-detection for the CLI.
 *
 * Read straight from `process.env` rather than `getCliEnv()` on purpose: the
 * CLI env snapshot is attached to telemetry payloads, and a user's `LANG` is
 * neither needed nor wanted there. Nothing here is ever sent anywhere.
 *
 * Detection runs ONCE at startup (`initLocale`), and only decides anything
 * when the user has no saved language — an explicit `/language` choice always
 * wins over the environment.
 */

import { isLocale, type Locale } from './types'

/** Explicit override, highest priority. Lets CI, tests and bug reports pin a
 *  locale without touching settings: `FREEBUFF_LOCALE=ru`. */
const OVERRIDE_VARS = ['FREEBUFF_LOCALE', 'CODEBUFF_LOCALE'] as const

/** POSIX locale variables, most specific first (`LC_ALL` overrides
 *  `LC_MESSAGES`, which overrides `LANG`). */
const POSIX_VARS = ['LC_ALL', 'LC_MESSAGES', 'LANG'] as const

/**
 * Parse a locale-ish environment value into a supported locale.
 *
 * `ru_RU.UTF-8`, `ru`, `ru-RU.UTF-8@euro` → `ru`.
 * Anything else that looks like a POSIX/BCP-47 tag → `en` (it names some
 * other language, so Russian is not wanted). Empty/unset/garbage → `undefined`
 * so the caller can keep looking instead of guessing `en` too early.
 */
const localeFromEnvValue = (raw: string | undefined): Locale | undefined => {
  const value = raw?.trim()
  if (!value) return undefined
  // `C`, `POSIX` and `C.UTF-8` are the identity locales, not a language.
  if (value === 'C' || value === 'POSIX') return undefined

  const tag = value.split(/[.@]/)[0]?.replace('_', '-')
  if (!tag) return undefined
  if (!/^[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8})*$/.test(tag)) return undefined

  return tag.toLowerCase().startsWith('ru') ? 'ru' : 'en'
}

/**
 * Best-effort locale guess from the environment. Never throws: a weird
 * environment must not be able to stop the CLI from starting.
 */
export const detectLocaleFromEnvironment = (): Locale | undefined => {
  try {
    for (const name of OVERRIDE_VARS) {
      const parsed = isLocale(process.env[name])
        ? process.env[name]
        : localeFromEnvValue(process.env[name])
      if (parsed) return parsed
    }

    for (const name of POSIX_VARS) {
      const parsed = localeFromEnvValue(process.env[name])
      // A POSIX var naming another language is a real answer: stop there so
      // `LC_ALL=en_US.UTF-8` beats a ru-flavoured `LANG`.
      if (parsed) return parsed
    }

    // ICU's own idea of the system locale — covers setups where no POSIX
    // variable is exported at all. Weakest signal, so it goes last.
    const resolved = Intl.DateTimeFormat().resolvedOptions().locale
    if (resolved?.toLowerCase().startsWith('ru')) return 'ru'
    if (resolved) return 'en'

    return undefined
  } catch {
    return undefined
  }
}
