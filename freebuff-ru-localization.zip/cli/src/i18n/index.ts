/**
 * Minimal i18n runtime for the Freebuff CLI.
 *
 * Design notes (deliberately small — no i18n dependency is added):
 *
 * - **English lives at the call site.** Every message is written in English
 *   where it is used, as the `fallback` argument: `t('help.title', 'Keyboard
 *   shortcuts')`. The `ru` catalog only stores overrides, so a missing key
 *   falls back to English by construction and untranslated UI cannot render
 *   as an empty string or a raw key.
 * - **Locale is module state, not a React context.** `/language` changes it
 *   once and every reader sees it; `useT()` subscribes React components to it
 *   so the TUI re-renders, while plain `t()` works in non-React code
 *   (command handlers, formatters) without a hook.
 * - **Default is `en`.** The locale is only ever *initialized* explicitly at
 *   startup (`initLocale`), so tests that assert English strings keep seeing
 *   English regardless of the machine's `LANG`.
 *
 * See GLOSSARY_RU.md for the terminology the Russian catalog follows and
 * README_RU.md for coverage and known limits.
 */

import { create } from 'zustand'

import {
  loadLanguagePreference,
  saveLanguagePreference,
} from '../utils/settings'
import { detectLocaleFromEnvironment } from './detect'
import { RU_MESSAGES } from './locales/ru'
import {
  DEFAULT_LOCALE,
  SUPPORTED_LOCALES,
  LOCALE_LABELS,
  isLocale,
  type Locale,
} from './types'

export type { Locale }
export { LOCALE_LABELS, SUPPORTED_LOCALES }

/** Values substituted into `{placeholders}`. */
export type MessageParams = Record<string, string | number>

/** English plural forms supplied inline at the call site. Russian forms come
 *  from the catalog as `${key}.one|few|many|other`, so callers never have to
 *  know Russian plural rules. */
export interface PluralForms {
  one?: string
  other: string
  few?: string
  many?: string
}

export type TFunction = (
  key: string,
  fallback: string,
  params?: MessageParams,
) => string

/** Catalogs per locale. Only non-English locales are stored (see file header). */
const CATALOGS: Partial<Record<Locale, Record<string, string>>> = {
  ru: RU_MESSAGES,
}

const useLocaleStore = create<{ locale: Locale }>(() => ({
  locale: DEFAULT_LOCALE,
}))

let initialized = false

/** The active locale. Safe to call from anywhere, including module scope. */
export const getLocale = (): Locale => useLocaleStore.getState().locale

/** React binding: re-renders the component whenever the locale changes. */
export const useLocale = (): Locale => useLocaleStore((state) => state.locale)

/** Whether `initLocale` (or `setLocale`) has run. */
export const isLocaleInitialized = (): boolean => initialized

/**
 * Resolve the locale once, at startup.
 *
 * Precedence: saved `/language` choice → environment auto-detection → `en`.
 * Calling it more than once is a no-op, so the user's choice can never be
 * silently overwritten mid-session.
 */
export const initLocale = (): Locale => {
  if (initialized) return getLocale()
  initialized = true

  const saved = loadLanguagePreference()
  const locale = isLocale(saved)
    ? saved
    : (detectLocaleFromEnvironment() ?? DEFAULT_LOCALE)
  useLocaleStore.setState({ locale })
  return locale
}

/** Switch locale for this session and remember the choice. */
export const setLocale = (locale: Locale): void => {
  initialized = true
  useLocaleStore.setState({ locale })
  saveLanguagePreference(locale)
}

/** Reset to the startup default. Test-only seam; does not touch settings. */
export const resetLocaleForTests = (): void => {
  initialized = false
  useLocaleStore.setState({ locale: DEFAULT_LOCALE })
} /** `{name}` interpolation. Tokens with no matching param are left verbatim so
 * a missing value is visible in the UI instead of vanishing as an empty
 * string. `${...}`, `%s`, `%d` and HTML/Markdown are never touched. */
const DOUBLE_BRACE = /{{([A-Za-z0-9_]+)}}/g
// Deliberately no lookbehind here: JavaScriptCore (Bun) silently fails to
// match a lookbehind whose character class mixes `{`, space and `$`, which
// would turn interpolation into a no-op. Instead this pass matches any braced
// token and the callback inspects the character in front of it, which keeps
// `{{name}}` (handled above) and `${name}` (literal template syntax) intact.
const BRACED = /\{([A-Za-z0-9_]+)\}/g

const interpolate = (template: string, params?: MessageParams): string => {
  if (!params) return template

  const value = (name: string): string | undefined => {
    const raw = params[name]
    return raw === undefined ? undefined : String(raw)
  }

  const withDouble = template.replace(
    DOUBLE_BRACE,
    (match, name: string) => value(name) ?? match,
  )

  return withDouble.replace(BRACED, (match, name: string, offset: number) => {
    const preceding = withDouble[offset - 1]
    if (preceding === '{' || preceding === '$') return match
    return value(name) ?? match
  })
}

const lookup = (key: string, fallback: string): string => {
  const locale = getLocale()
  if (locale === DEFAULT_LOCALE) return fallback
  return CATALOGS[locale]?.[key] ?? fallback
}

/**
 * Translate `key`. Returns the English `fallback` when the locale is English
 * or the key is missing from the active catalog.
 *
 * @example t('help.title', 'Keyboard shortcuts')
 * @example t('lang.current', 'Interface language: {language}', { language })
 */
export const t: TFunction = (key, fallback, params) =>
  interpolate(lookup(key, fallback), params)

const pluralRules = new Map<Locale, Intl.PluralRules>()

/** CLDR plural category for the locale: `one | few | many | other`. */
const pluralCategory = (locale: Locale, count: number): Intl.LDMLPluralRule => {
  let rules = pluralRules.get(locale)
  if (!rules) {
    rules = new Intl.PluralRules(locale)
    pluralRules.set(locale, rules)
  }
  return rules.select(count)
}

/** English only needs `one`/`other`; the other categories exist so a caller
 *  could supply them, and so this stays total over CLDR categories. */
const englishForm = (
  forms: PluralForms,
  category: Intl.LDMLPluralRule,
): string => {
  if (category === 'one') return forms.one ?? forms.other
  if (category === 'few') return forms.few ?? forms.other
  if (category === 'many') return forms.many ?? forms.other
  return forms.other
}

/**
 * Plural-aware message. `count` is always available as `{count}`.
 *
 * Resolution order for the active locale: exact category form → `.other` →
 * the English `forms` passed inline. Russian therefore gets its four forms
 * from the catalog while English callers only write `one`/`other`.
 *
 * `{count}` is formatted through `Intl.NumberFormat` for non-English locales
 * (so Russian renders `1 234 сообщения` and `1,5 файла`) and left as the raw
 * number under `en`, where existing copy and its tests are byte-identical.
 *
 * @example tp('files.count', n, { one: '{count} file', other: '{count} files' })
 */
export const tp = (
  key: string,
  count: number,
  forms: PluralForms,
  params?: MessageParams,
): string => {
  const locale = getLocale()
  const category = pluralCategory(locale, count)

  let template: string | undefined
  if (locale !== DEFAULT_LOCALE) {
    const catalog = CATALOGS[locale]
    template = catalog?.[`${key}.${category}`] ?? catalog?.[`${key}.other`]
  }
  template ??= englishForm(forms, category)

  const renderedCount =
    locale === DEFAULT_LOCALE
      ? count
      : new Intl.NumberFormat(locale === 'ru' ? 'ru-RU' : 'en-US').format(count)

  return interpolate(template, { ...params, count: renderedCount })
}

const intlLocale = (): string => (getLocale() === 'ru' ? 'ru-RU' : 'en-US')

/** Locale-aware number formatting. */
export const formatNumber = (
  value: number,
  options?: Intl.NumberFormatOptions,
): string => new Intl.NumberFormat(intlLocale(), options).format(value)

/** Locale-aware date/time formatting. */
export const formatDate = (
  value: Date | number,
  options?: Intl.DateTimeFormatOptions,
): string => new Intl.DateTimeFormat(intlLocale(), options).format(value)

/**
 * React hook: subscribes the component to locale changes and returns `t`.
 * Use this in components so a `/language` switch repaints them; plain `t()`
 * is fine everywhere else.
 */
export const useT = (): TFunction => {
  useLocaleStore((state) => state.locale)
  return t
}

/** Every locale this build can switch to, with its self-name for the picker. */
export const listLocales = (): { locale: Locale; label: string }[] =>
  SUPPORTED_LOCALES.map((locale) => ({ locale, label: LOCALE_LABELS[locale] }))

/** True when `value` names a locale this build ships (`ru`, `RU`, `ru-RU`). */
export const parseLocale = (value: string): Locale | undefined => {
  const tag = value.trim().split(/[._-]/)[0]?.toLowerCase()
  return isLocale(tag) ? tag : undefined
}
