/**
 * Russian (ru-RU) message catalog.
 *
 * Flat dotted keys, one entry per UI string. English is NOT duplicated here:
 * it lives at the call site as the `fallback` argument of `t()`, so a key
 * missing from this file renders English by construction.
 *
 * Rules followed here — see GLOSSARY_RU.md:
 *   - only user-facing strings; code, identifiers, CLI commands, paths, URLs,
 *     model/provider/brand names and log lines stay in English;
 *   - `{placeholders}` are copied verbatim, including their names;
 *   - plural keys are `key.one` / `key.few` / `key.many` / `key.other`,
 *     selected through `Intl.PluralRules('ru')`;
 *   - «ё» is written out in full and quotation uses «…», per Russian
 *     typography.
 *
 * `i18n/__tests__/locale-catalog.test.ts` enforces the mechanical half of
 * this: no duplicate keys, well-formed keys, at least one Cyrillic letter per
 * value, no stale keys, placeholder parity with the English source, and
 * complete plural families.
 *
 * @see cli/src/i18n/index.ts for `t()` / `tp()`.
 */

export const RU_MESSAGES: Record<string, string> = {
  // --- language switcher (/language) -------------------------------------
  'lang.status':
    'Язык интерфейса: {name} ({locale}). Доступны: {available}. Смена: /language <locale>.',
  'lang.unsupported': 'Неподдерживаемый язык «{value}». Доступны: {available}.',
  'lang.changed': 'Язык интерфейса переключён на {name} ({locale}).',

  // --- slash command menu (cli/src/data/slash-commands.ts) ---------------
  // Key = `cmd.<command id>.description`; the English source of truth is the
  // `description:` literal for the same id in slash-commands.ts.
  'cmd.ads:report.description':
    'Сообщить о проблеме с рекламой: /ads:report <номер>, без аргумента — список недавних объявлений',
  'cmd.help.description': 'Показать горячие клавиши и подсказки',
  'cmd.diagnostics.description':
    'Показать расход ресурсов CLI и PID запущенных инструментов',
  'cmd.ads:enable.description': 'Включить контекстную рекламу',
  'cmd.ads:disable.description': 'Выключить контекстную рекламу',
  'cmd.init.description': 'Создать стартовый файл knowledge.md',
  'cmd.usage.description': 'Показать баланс кредитов и лимит подписки',
  'cmd.subscribe.description': 'Оформить подписку, чтобы увеличить лимит',
  'cmd.interview.description':
    'ИИ задаёт уточняющие вопросы, чтобы превратить запрос в спецификацию',
  'cmd.plan.description': 'Составить план реализации запроса',
  'cmd.review.description': 'Проверить изменения кода',
  'cmd.queue.description':
    'Изменить, переставить или удалить отложенные сообщения',
  'cmd.todo.description': 'Показать текущий список задач и прогресс',
  'cmd.new.description': 'Очистить историю и начать новый чат',
  'cmd.history.description':
    'Просматривать прошлые беседы и возвращаться к ним',
  'cmd.copy.description':
    'Скопировать всю беседу (сообщения и результаты инструментов) в буфер обмена',
  'cmd.export.description':
    'Сохранить беседу в файл (.md, либо .json с исходными сообщениями)',
  'cmd.agent:gpt-5.description': 'Подключить агента GPT-5 для сложных задач',
  'cmd.feedback.description': 'Поделиться отзывом о {brand}',
  'cmd.bash.description': 'Режим bash — ввод с символом «!» в начале строки',
  'cmd.image.description':
    'Прикрепить изображение (или Ctrl+V из буфера обмена)',
  'cmd.theme:toggle.description': 'Переключить светлую и тёмную темы',
  'cmd.byok.description':
    'Настройка прямого доступа к OpenRouter или OpenAI-compatible',
  'cmd.model.description': 'Выбрать модель для следующего сообщения',
  'cmd.reasoning.description': 'Выбрать уровень рассуждений для модели',
  'cmd.deals.description':
    'Партнёрские предложения: /deals use <номер> открывает одно, /deals off скрывает их',
  'cmd.end-session.description': 'Завершить текущую сессию',
  'cmd.dashboard.description':
    'Открыть в браузере статистику, серию дней и аккаунт',
  'cmd.logout.description': 'Выйти из аккаунта',
  'cmd.exit.description': 'Выйти из CLI',
  'cmd.language.description': 'Показать или сменить язык интерфейса',

  // --- keyboard shortcut overlay (cli/src/components/help-banner.tsx) -----
  'help.title': 'Горячие клавиши',
  'help.section.compose': 'Ввод',
  'help.section.chat': 'Чат',
  'help.section.conversation': 'Беседа',
  'help.compose.commands': 'Команды',
  'help.compose.mention-files': 'Упомянуть файлы',
  'help.compose.use-agent': 'Выбрать агента',
  'help.compose.newline-ctrl-j': 'Новая строка',
  'help.compose.newline-opt-enter': 'Новая строка',
  'help.compose.shell-command': 'Команда в оболочке',
  'help.chat.help': 'Справка (пустой ввод)',
  'help.chat.history': 'История (пустой ввод)',
  'help.chat.prompts': 'Подсказки (пустой ввод)',
  'help.chat.new-chat': 'Новый чат',
  'help.chat.model-reasoning': 'Модель / рассуждения',
  'help.chat.edit-queued': 'Правка отложенных сообщений',
  'help.conversation.close-help': 'Закрыть справку / остановить',
  'help.conversation.clear-stop-quit': 'Очистить / остановить / выйти',
  'help.conversation.toggle-agents': 'Развернуть / свернуть агентов',
  'help.conversation.copy-chat': 'Скопировать чат',
  'help.conversation.export-chat': 'Экспорт чата',
  'help.conversation.select-copy': 'Выделить и скопировать текст',
  'help.footer.credits': '/subscribe · /usage · 1 кредит = 1 цент',

  // --- status bar (cli/src/components/status-bar.tsx) --------------------
  'status.exit-warning': 'Нажмите Ctrl-C ещё раз, чтобы выйти',
  'status.reconnected': 'Переподключено',
  'status.retrying': 'повторяем…',
  'status.capacity-wait': 'много запросов — вы в очереди, скоро начнём…',
  'status.cannot-reach-servers':
    'Не удаётся связаться с серверами {brand}. Повторяем… Попробуйте другую сеть.',
  'status.thinking': 'думаем…',
  'status.working': 'работаем…',
  'status.unlimited': 'без ограничений',

  // --- transient toasts (clipboard/status messages) -----------------------
  'feedback.sent': 'Отзыв отправлен!',
  'feedback.failed': 'Не удалось отправить отзыв',

  // --- composer: input-mode labels and placeholders ----------------------
  // (cli/src/utils/input-modes.ts; mode keys are lowercased there)
  'input.mode.default.placeholder': 'введите задачу по коду или / для команд',
  'input.mode.homedir.placeholder': 'введите задачу по коду или / для команд',
  'input.mode.usage.placeholder': 'введите задачу по коду или / для команд',
  'input.mode.help.placeholder': 'введите задачу по коду или / для команд',
  'input.mode.bash.placeholder': 'введите команду bash…',
  'input.mode.interview.label': 'Собеседование',
  'input.mode.interview.placeholder':
    'опишите фичу, баг или другой запрос, который нужно раскрыть…',
  'input.mode.skill.label': 'Навык',
  'input.mode.skill.placeholder':
    'добавьте инструкции к навыку или нажмите Enter, чтобы запустить как есть…',
  'input.mode.plan.label': 'План',
  'input.mode.plan.placeholder': 'опишите, что нужно запланировать…',
  'input.mode.review.label': 'Проверка',
  'input.mode.review.placeholder': 'опишите, что нужно проверить…',
  'input.mode.image.placeholder':
    'введите путь к изображению или Ctrl+V для вставки',

  // --- login screen (cli/src/components/login-modal.tsx) -----------------
  'login.loading': 'Загрузка…',
  'login.press-enter': 'Нажмите ENTER, чтобы войти…',
  'login.waiting': 'Ожидание входа…',
  'login.copy.unverified':
    'Копирование отправлено в терминал — вставьте, чтобы проверить.',
  'login.copy.success': '✓ Ссылка скопирована в буфер обмена!',
  'login.copy-button.idle': '[ Копировать (c) ]',
  'login.copy-button.copied': '[ ✓ Скопировано! ]',
  'login.url.narrow': 'Откройте эту ссылку, чтобы войти:',
  'login.url.wide': 'Откройте эту ссылку в браузере, чтобы войти:',
  'login.url-wrapped':
    '⚠ Ссылка переносится на несколько строк — по клику она обрежется. Нажмите c, чтобы скопировать её целиком.',
  'login.error.prefix': 'Ошибка: ',
  'login.error.timeout': 'Время ожидания входа истекло. Попробуйте ещё раз.',
  'login.error.retry': 'Попробуйте ещё раз',
  'login.error.restart': 'Перезапустите CLI и попробуйте ещё раз',
  'login.invalid-key.narrow':
    '⚠ Найден API-ключ, но он недействителен. Войдите снова.',
  'login.invalid-key.wide':
    '⚠ Найден API-ключ, но он недействителен. Войдите снова, чтобы продолжить.',
  'login.tip.prefix': 'Подсказка: не удаётся скопировать? Выйдите и выполните',
  'login.tip.suffix': 'вместо этого.',

  // --- transient toasts and command feedback ------------------------------
  'toast.send-prompt-failed': 'Не удалось отправить запрос',
  'toast.send-followup-failed': 'Не удалось отправить продолжение',
  'toast.send-review-failed': 'Не удалось отправить запрос на проверку',
  'toast.paste-image-failed': 'Не удалось вставить изображение',
  'toast.add-image-failed': 'Не удалось добавить изображение',
  'toast.update-preference-failed': 'Не удалось обновить настройку',
  'toast.nothing-to-copy': 'Нечего копировать — беседа пуста.',
  'toast.login-required-usage': 'Сначала войдите, чтобы посмотреть расход.',
  'toast.processing-attachments': 'обработка вложений…',

  // --- pluralized strings (cli/src/i18n/__tests__/i18n.test.ts fixture) ---
  // `ru.demo` is exercised by the core test; it is the reference for how the
  // four Russian categories are written.
  'ru.demo.one': '{count} файл',
  'ru.demo.few': '{count} файла',
  'ru.demo.many': '{count} файлов',
  'ru.demo.other': '{count} файла',

  // --- message queue (queue-panel.tsx, use-queue-ui.ts) ------------------
  'queue.title.one': '{count} сообщение',
  'queue.title.few': '{count} сообщения',
  'queue.title.many': '{count} сообщений',
  'queue.title.other': '{count} сообщения',
  'queue.paused-preview.one':
    '⏸ {count} сообщение отложено — ваше следующее сообщение уйдёт первым',
  'queue.paused-preview.few':
    '⏸ {count} сообщения отложено — ваше следующее сообщение уйдёт первым',
  'queue.paused-preview.many':
    '⏸ {count} сообщений отложено — ваше следующее сообщение уйдёт первым',
  'queue.paused-preview.other':
    '⏸ {count} сообщения отложено — ваше следующее сообщение уйдёт первым',

  // --- sponsored proposal summary (blocks/sponsored-proposal-block.tsx) --
  'proposal.changed-files.one': 'Изменён {count} файл. Ничего не закоммичено.',
  'proposal.changed-files.few':
    'Изменено {count} файла. Ничего не закоммичено.',
  'proposal.changed-files.many':
    'Изменено {count} файлов. Ничего не закоммичено.',
  'proposal.changed-files.other':
    'Изменено {count} файла. Ничего не закоммичено.',

  // --- /copy success toast (commands/copy-conversation.ts) ---------------
  'copy.message-count.one': '{count} сообщение',
  'copy.message-count.few': '{count} сообщения',
  'copy.message-count.many': '{count} сообщений',
  'copy.message-count.other': '{count} сообщения',
  'copy.tool-calls-trimmed.one': 'обрезан {count} крупный вызов инструмента',
  'copy.tool-calls-trimmed.few': 'обрезано {count} крупных вызова инструмента',
  'copy.tool-calls-trimmed.many':
    'обрезано {count} крупных вызовов инструментов',
  'copy.tool-calls-trimmed.other':
    'обрезано {count} крупного вызова инструмента',
  'copy.older-truncated': 'старые сообщения усечены',
  'copy.success': 'Скопирована беседа · {count}',
  'copy.success-trimmed':
    'Скопирована беседа · {count} ({notes} — чтобы влезть в буфер обмена)',
}
