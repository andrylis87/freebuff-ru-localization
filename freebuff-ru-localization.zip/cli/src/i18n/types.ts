/**
 * Locale vocabulary shared by the i18n runtime and the settings store.
 *
 * This module is intentionally dependency-free (types and constants only) so
 * `utils/settings.ts` can import the `Locale` type without pulling the i18n
 * runtime — and its settings dependency — into a cycle.
 */

/** Locales the CLI ships a catalog for. `en` is the source language: every
 *  message is written in English at the call site and only `ru` is stored as
 *  a catalog, so an untranslated key falls back to English by construction. */
export type Locale = 'en' | 'ru'

export const SUPPORTED_LOCALES: readonly Locale[] = ['en', 'ru']

export const DEFAULT_LOCALE: Locale = 'en'

/** Language names are shown in their own language — the convention every
 *  language picker uses, and the only way "Русский" reads correctly to the
 *  person choosing it. */
export const LOCALE_LABELS: Record<Locale, string> = {
  en: 'English',
  ru: 'Русский',
}

/** True for a value read out of settings or the environment. */
export const isLocale = (value: unknown): value is Locale =>
  typeof value === 'string' &&
  (SUPPORTED_LOCALES as readonly string[]).includes(value)
