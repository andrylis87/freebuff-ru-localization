import { t } from '../i18n'
import { IS_FREEBUFF } from './constants'

// Input mode types and configurations
// To add a new mode:
// 1. Add it to the InputMode type
// 2. Add its configuration to INPUT_MODE_CONFIGS

export type InputMode =
  | 'default'
  | 'bash'
  | 'homeDir'
  | 'plan'
  | 'review'
  | 'interview'
  | 'skill'
  | 'usage'
  | 'image'
  | 'help'
  | 'outOfCredits'
  | 'subscriptionLimit'

// Theme color keys that are valid color values (must match ChatTheme keys)
export type ThemeColorKey =
  | 'foreground'
  | 'background'
  | 'error'
  | 'warning'
  | 'success'
  | 'info'
  | 'muted'
  | 'imageCardBorder'
  | 'link'

export type InputModeConfig = {
  /** Prefix icon shown before input (e.g., "!" for bash) */
  icon: string | null
  /** Colored label shown before input (e.g., "Plan") */
  label: string | null
  /** Theme color key for icon and border */
  color: ThemeColorKey
  /** Input placeholder text */
  placeholder: string
  /** Width adjustment for the prefix (icon width + padding) */
  widthAdjustment: number
  /** Whether to show the agent mode toggle */
  showAgentModeToggle: boolean
  /** Whether to disable slash command suggestions */
  disableSlashSuggestions: boolean
  /** Whether keyboard shortcuts (Escape, Backspace) can exit this mode */
  blockKeyboardExit: boolean
}

export const INPUT_MODE_CONFIGS: Record<InputMode, InputModeConfig> = {
  default: {
    icon: null,
    label: null,
    color: 'foreground',
    placeholder: 'enter a coding task or / for commands',
    widthAdjustment: 0,
    showAgentModeToggle: true,
    disableSlashSuggestions: false,
    blockKeyboardExit: false,
  },
  bash: {
    icon: null,
    label: '!',
    color: 'info',
    placeholder: 'enter bash command...',
    widthAdjustment: 4, // ` ! ` (3 chars) + 1 padding
    showAgentModeToggle: false,
    disableSlashSuggestions: true,
    blockKeyboardExit: false,
  },
  homeDir: {
    icon: null,
    label: null,
    color: 'warning',
    placeholder: 'enter a coding task or / for commands',
    widthAdjustment: 0,
    showAgentModeToggle: true,
    disableSlashSuggestions: false,
    blockKeyboardExit: false,
  },
  interview: {
    icon: null,
    label: 'Interview',
    color: 'info',
    placeholder: 'describe a feature/bug or other request to be fleshed out...',
    widthAdjustment: 12,
    showAgentModeToggle: false,
    disableSlashSuggestions: true,
    blockKeyboardExit: false,
  },
  skill: {
    icon: null,
    // Label is replaced with the pending skill's name at render time
    // (chat-input-bar), so the mode banner names what is about to run.
    label: 'Skill',
    color: 'info',
    placeholder: 'add instructions for this skill, or press Enter to run it as-is...',
    widthAdjustment: 8,
    showAgentModeToggle: false,
    disableSlashSuggestions: true,
    blockKeyboardExit: false,
  },
  plan: {
    icon: null,
    label: 'Plan',
    color: 'info',
    placeholder: 'describe what you want to plan...',
    widthAdjustment: 7,
    showAgentModeToggle: false,
    disableSlashSuggestions: true,
    blockKeyboardExit: false,
  },
  review: {
    icon: null,
    label: 'Review',
    color: 'info',
    placeholder: 'describe what to review...',
    widthAdjustment: 9,
    showAgentModeToggle: false,
    disableSlashSuggestions: true,
    blockKeyboardExit: false,
  },
  usage: {
    icon: null,
    label: null,
    color: 'foreground',
    placeholder: 'enter a coding task or / for commands',
    widthAdjustment: 0,
    showAgentModeToggle: true,
    disableSlashSuggestions: false,
    blockKeyboardExit: false,
  },
  image: {
    icon: '📎',
    label: null,
    color: 'imageCardBorder',
    placeholder: 'enter image path or Ctrl+V to paste',
    widthAdjustment: 3, // emoji width + padding
    showAgentModeToggle: false,
    disableSlashSuggestions: true,
    blockKeyboardExit: false,
  },
  help: {
    icon: null,
    label: null,
    color: 'info',
    placeholder: 'enter a coding task or / for commands',
    widthAdjustment: 0,
    showAgentModeToggle: true,
    disableSlashSuggestions: false,
    blockKeyboardExit: false,
  },
  outOfCredits: {
    icon: null,
    label: null,
    color: 'warning',
    placeholder: '',
    widthAdjustment: 0,
    showAgentModeToggle: false,
    disableSlashSuggestions: true,
    blockKeyboardExit: false,
  },
  subscriptionLimit: {
    icon: null,
    label: null,
    color: 'warning',
    placeholder: '',
    widthAdjustment: 0,
    showAgentModeToggle: false,
    disableSlashSuggestions: true,
    blockKeyboardExit: true, // User must click "Continue with credits" or wait for reset
  },
}

// In Freebuff, never show the agent mode toggle
if (IS_FREEBUFF) {
  for (const key of Object.keys(INPUT_MODE_CONFIGS) as InputMode[]) {
    INPUT_MODE_CONFIGS[key].showAgentModeToggle = false
  }
}

/**
 * Read a mode's config with its visible copy localized.
 *
 * Labels and placeholders live in English in `INPUT_MODE_CONFIGS` above (the
 * source of truth, and what renders under the default `en` locale); `t()`
 * overrides them per locale. The mode's machine name stays English — it is a
 * key, not copy — and callers keep reading the same fields as before.
 */
export function getInputModeConfig(mode: InputMode): InputModeConfig {
  const config = INPUT_MODE_CONFIGS[mode]
  const key = mode.toLowerCase()
  return {
    ...config,
    label:
      config.label === null ? null : t(`input.mode.${key}.label`, config.label),
    placeholder: t(`input.mode.${key}.placeholder`, config.placeholder),
  }
}
